<?php

file_put_contents('./help/headers.txt', var_export(apache_request_headers(), true));
file_put_contents('./help/post.txt', var_export($_POST, true));
file_put_contents('./help/files.txt', var_export($_FILES, true));

$bodyBase64 = $_POST['body'];
$lang = $_POST['lang'];

$body = base64_decode($bodyBase64);

file_put_contents('../img/img.txt', $body);

$dir = dirname(__FILE__);

if($lang == "eng")
	$system_command = "$dir/prep_sound_eng.sh ";
else
	$system_command = "$dir/prep_sound_hrv.sh ";

$output = shell_exec($system_command);

$original = file_get_contents('../img/imgBase64.txt');

$len = filesize('../img/imgBase64.txt')+7;

header('Content-Length: ' . $len);

echo "_SOUND_";

echo $original;

?>

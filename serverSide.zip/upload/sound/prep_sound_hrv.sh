espeak -f ../img/img.txt -w ../img/img.wav -v mb-cr1 -s 125

lame ../img/img.wav ../img/img.mp3
base64 ../img/img.mp3 > ../img/imgBase64.txt

text2wave ../img/img.txt -eval '(voice_us1_mbrola)' -o ../img/img.wav

lame ../img/img.wav ../img/img.mp3
base64 ../img/img.mp3 > ../img/imgBase64.txt

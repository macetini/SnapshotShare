<?php

file_put_contents('./help/headers.txt', var_export(apache_request_headers(), true));
file_put_contents('./help/post.txt', var_export($_POST, true));
file_put_contents('./help/files.txt', var_export($_FILES, true));

move_uploaded_file($_FILES['photoFile']['tmp_name'], '../img/img.jpg');

$lang = $_POST['lang'];

$output =  system('./prep_text.sh '.$lang);

$original=file_get_contents('../img/img.txt');

echo "_TEXT__";

echo base64_encode($original);

?>

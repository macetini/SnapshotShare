convert ../img/img.jpg ../img/img.tif
tesseract ../img/img.tif ../img/img -l $1
